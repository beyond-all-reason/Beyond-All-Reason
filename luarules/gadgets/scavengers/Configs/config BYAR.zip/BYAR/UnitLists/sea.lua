T0SeaUnits = {
"armpt",
"corpt",
}

T1SeaUnits = {
"armpt",
"armdecade",
"armrecl",
"armpship",
"armsub",
"armpincer",
"corpt",
"coresupp",
"correcl",
"corpship",
"corsub",
"corgarp",
--hovercraft
"armsh",
"armmh",
"armah",
"armanac",
"corsh",
"cormh",
"corah",
"corsnap",
}

T2SeaUnits = {
"armroy",
--"armsjam",
"armmls",
"armsubk",
"armaas",
"armcrus",
--"armcarry",
"armserp",
"armmship",
"armcroc",
"corroy",
--"corsjam",
"cormls",
"corshark",
"corarch",
"corcrus",
--"corcarry",
"corssub",
"cormship",
"corseal",
--hovercraft
"corhal",
}

T3SeaUnits = {
"armbats",
"armepoch",
"corbats",
"corblackhy",
--hovercraft
"armlun",
"corsok",
}

T4SeaUnits = {
"corcrwbosst2",
"corcrwbosst2",
}