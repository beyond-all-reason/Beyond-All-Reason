NoSelfdList = {
"cormaw",
"armclaw",
"corfmd",
"coramd",


-- These operate through other modules
--"cornanotc",
--"armnanotc",
--"armnanotcplat",
--"cornanotcplat",
--"armcom",
--"corcom",
--"armrectr",
--"cornecro",
}