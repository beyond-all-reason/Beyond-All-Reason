T0AirUnits = {
"armpeep",
"armfig",
"corfink",
"corbw",
"corveng",

}

T1AirUnits = {
"armthund",
"armsehak",
"armfig",
"corshad",
"corbw",
"corveng",
"corhunt",

}

T2AirUnits = {
"armsb",
"armkam",
"armawac",
"armbrawl",
"armsaber",
"corsb",
"corawac",
"corsfig",
"corcut",

}

T3AirUnits = {
"armhawk",
"armawac",
"armsb",
"armblade",
"armstil",
"armliche",
"armpnix",
"corsb",
"corvamp",
"corhurc",
--"corape", exluded because of interference with corap factory
"corcrw",
"corawac",

}

T4AirUnits = {
"corcrwbosst2_scav",
"corcrwbosst2_scav",
}