ConstructorsList = {
"armcom",
"corcom",
}

ConstructorsCounter = {
UDN.armcom_scav.id,
UDN.corcom_scav.id,
}

AssistUnits = {
"armnanotc",
"cornanotc",
"armnanotcplat",
"cornanotcplat",
}

Resurrectors = {
"armrectr",
"cornecro",
}

ResurrectorsSea = {
"armrecl",
"correcl",
}

Collectors = {
"armck",
"armack",
"armdecom",
"armcv",
"armbeaver",
"armacv",
"armca",
"armcsa",
"armaca",
"armcs",
"armacsub",
"armch",
"corck",
"corack",
"cordecom",
"corcv",
"cormuskrat",
"coracv",
"corca",
"corcsa",
"coraca",
"corcs",
"coracsub",
"corch",
}